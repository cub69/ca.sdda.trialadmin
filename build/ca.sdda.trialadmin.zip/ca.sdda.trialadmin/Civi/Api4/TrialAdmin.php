<?php
namespace Civi\Api4;

/**
 * TrialAdmin entity.
 *
 * Provided by the SDDA Trial Administration Module extension.
 *
 * @package Civi\Api4
 */
class TrialAdmin extends Generic\DAOEntity {

}
