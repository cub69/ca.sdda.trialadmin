<?php
namespace Civi\Api4;

/**
 * TrialComponents entity.
 *
 * Provided by the SDDA Trial Administration Module extension.
 *
 * @package Civi\Api4
 */
class TrialComponents extends Generic\DAOEntity {

}
