<?php
namespace Civi\Api4;

/**
 * TrialadminLog entity.
 *
 * Provided by the SDDA Trial Administration Module extension.
 *
 * @package Civi\Api4
 */
class TrialadminLog extends Generic\DAOEntity {

}
